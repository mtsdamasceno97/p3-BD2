import psycopg2
try:
   conn = psycopg2.connect(host='127.0.0.1', port=5432, database='dvdrental', user='postgres', password='dba')
   print('(1) Conexão com o database realizada com Sucesso!')
   cursor = conn.cursor()
   if( cursor != None):
       print('(2) Cursor obtido com sucesso!')

   # exibindo as propriedades da conexao PostgreSQL 
   print ( conn.get_dsn_parameters(),"\n")

   print('(3.1) Testando o método fetchone()')
   cursor.execute('SELECT version()')
   db_version = cursor.fetchone()  
   print(type(db_version))
   print(db_version)
   print()
   
   print('(3.2) Testando o fetchall()')
   cursor.execute('SELECT first_name, last_name FROM actor LIMIT 5')
   print("Número total de linhas recuperadas: ", cursor.rowcount)

   resultado = cursor.fetchall()
   print(type(resultado))
   print(resultado)
   print()

   print('(3.3) Testando o fetchone() com while')
   cursor.execute('SELECT first_name, last_name FROM actor LIMIT 5')
   print("Número total de linhas recuperadas: ", cursor.rowcount)
   row = cursor.fetchone()
   while row is not None:
      print(row)
      row = cursor.fetchone()

   print()
   print('(4) Criando tabelas via execute()')
   sql = """
        CREATE OR REPLACE TABLE alunos (
            aluno_id SERIAL PRIMARY KEY,
            nome VARCHAR(40) NOT NULL
        )
        """
   cursor.execute(sql)
   print('\tTabela ALUNOS criada com sucesso!')
   print()

   print('(5) INSERT via execute()')
   sql = """
        INSERT INTO alunos (aluno_id,nome)
        VALUES (%s,%s)
        """
   cursor.execute(sql, (1,'Alex'))
   cursor.execute(sql, (2,'Leo'))
   cursor.execute(sql, (3,'Junior'))

   

   

   

   
   
except psycopg2.OperationalError as oe:
   print('ERRO NA CONEXÃO:', oe)
   print('CLASSE DO ERRO:',type(oe).__name__) # OU  print('CLASSE DO ERRO:',e.__class__.__name__)
except psycopg2.DatabaseError as dbe:
   print('ERRO NA CONEXÃO:', dbe)
   print('CLASSE DO ERRO:',e.__class__.__name__)
except:
   print('ERRO GENÉRICO')
finally:
   print('(3.4) Fechando a conexão')
   if( conn ):
      cursor.close()
      conn.close()
   
