/*
 * Este exemplo mostra como listar todos os nomes contidos na tabela EMP do usu�rio scott
 * Utiliza o driver de conexao JDBC THIN.  
 */

import java.sql.*;

class Employee
{
  public static void main (String args []) throws SQLException  {

    // Load the Oracle JDBC driver
    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

    // Connect to the database
    // You must put a database name after the @ sign in the connection URL.
    // You can use either the fully specified SQL*net syntax or a short cut
    // syntax as <host>:<port>:<sid>.  The example uses the short cut syntax.
    String url = "jdbc:oracle:thin:@dlsun511:1721:dbms733";
    String userName = "scott";
    String password = "tiger";

    if (args.length > 0) 
	url = args[0];
    if (args.length > 1) 
	 userName = args[1];
    if (args.length > 2) 
	password = args[2];

    Connection conn =
      DriverManager.getConnection (url, userName, password);

    // Create a Statement
    Statement stmt = conn.createStatement ();

    // Select the ENAME column from the EMP table
    ResultSet rset = stmt.executeQuery ("select ENAME from EMP");

    // Iterate through the result and print the employee names
    while (rset.next ())
      System.out.println (rset.getString (1));

    rset.close();
    conn.close();
  }
}
