/*
 * Created on 02/06/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Alex
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.util.Properties;
import java.io.*;
import java.sql.*;


public class TestaConexao {

	public static void main(String[] args) {
		Properties config = new Properties();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream("config.properties");			
			config.load(fis);
		} catch (IOException io) {
			System.err.println( io.getMessage());
		}
		Connection con;
		String driver = config.getProperty("connection.driver");
		String url = config.getProperty("connection.url");
		String user = config.getProperty("user.name");
		String password = config.getProperty("user.password");
		try {
			/* Instances of the class Class represent classes and interfaces in a running Java application
			 * Class has no public constructor. Instead Class objects are constructed automatically by the Java Virtual Machine*/
			/* Returns the Class object associated with the class or interface with the given string name. */ 
			Class.forName( driver );
			con = DriverManager.getConnection(url, user, password);
			/* Fechando a conexao com o banco */
			con.setCatalog("javamail");
			/* Criando uma expressao */
			Statement st = con.createStatement();
			
			/* Executando uma consulta */
			//ResultSet rs = st.executeQuery("Select login, senha from usuario where nome like 'a%'");
			ResultSet rs = st.executeQuery("Select login, senha from si_usuarios where nome like 'a%'");
			/* Lendo os dados e exibindo no console*/
			System.out.println("login   \tNome");
			System.out.println("========\t===============================");
			while (rs.next()) {
				System.out.print(rs.getString("login"));
				System.out.println("\t\t" + rs.getString("senha"));
			}
			rs.close();
			st.close();
		
			con.close();
		} catch (ClassNotFoundException sql) {
			System.out.println("Erro ao carregar o driver JDBC.");
			sql.printStackTrace();
		} catch (SQLException sql) {
			System.out.println("Erro ao tentar conectar ao banco de dados");
			sql.printStackTrace();
		}
		
		
		/* Fechando a conexao */
		
	}
}
