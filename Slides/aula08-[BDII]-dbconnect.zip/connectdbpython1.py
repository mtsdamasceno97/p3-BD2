import psycopg2
try:
   conn = psycopg2.connect(host='127.0.0.1', port=5432, database='dvdrental', user='postgres', password='dba')
   print('Sucesso na Conexão!')
   cursor = conn.cursor()
   if( cursor != None):
       print('Cursor obtido com sucesso.')
 
except psycopg2.OperationalError as oe:
   print('ERRO NA CONEXÃO:', oe)
   print('CLASSE DO ERRO:',type(oe).__name__) # OU  print('CLASSE DO ERRO:',e.__class__.__name__)
except psycopg2.DatabaseError as dbe:
   print('ERRO NA CONEXÃO:', dbe)
   print('CLASSE DO ERRO:',e.__class__.__name__)
except:
   print('ERRO GENÉRICO')
   
