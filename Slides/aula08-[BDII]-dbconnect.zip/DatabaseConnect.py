import psycopg2 # adptador para conexão ao PostgreSQL


from config import config # configuração dos parâmetros de conexão ao banco
import traceback # caso deseje imprimir o traceback que antes era apresentado na tela

class DatabaseConnect:
    __instance = None  # Keep instance reference (Singleton)


    def __new__(cls, *args, **kwargs):
        if not cls.__instance:
            cls.__instance = object.__new__(cls, *args, **kwargs)
        return cls.__instance

    def __init__(self, database = 'postgresql'):
        self.__connection = None # objeto responsável pela conexão com o banco
        self.__cursor = None
        
        # read connection parameters
        # retorna um dicionário {parametro:value,}
        params = config(filename='database.ini', section = database)

       # atributos de configuração da conexão
        self.__database = database
        self.__host = params['host']
        self.__port = params['port']
        self.__schema = params['database']
        self.__user = params['user']
        self.__password = params['password']        

        #print(params)


      
    @staticmethod 
    def getInstance():
        return DatabaseConnect.__instance

    def getConnection(self):
        if (self.__connection == None):
            self.__connection = psycopg2.connect(host = self.__host , port = self.__port , database= self.__schema, \
                                                 user = self.__user, password = self.__password )
        return self.__connection

    def getCursor(self):
        if( self.__cursor == None):
            if (self.__connection == None):
                self.__connection = psycopg2.connect(host = self.__host , port = self.__port , database= self.__schema, \
                                                 user = self.__user, password = self.__password )
            self.__cursor = self.__connection.cursor()
            
        return self.__cursor


    def version(self):
        if (self.__cursor == None):
            self.getCursor()
        self.__cursor.execute('SELECT version()')
        print( self.__cursor.fetchone()[0])
        print(self.__connection.autocommit)
        
        

    def __str__(self):
        return f'Singleton DatabaseConnection.\nParametrização recuperada para comunicação ao banco de dados:\ndatabase = {self.__database}\nhost = {self.__host} \nporta = {self.__port}\nesquema = \'{self.__schema}\' \nusuario = {self.__user}'


    def submitsql(self, sql, tupla=None):
        if (self.__cursor == None):
            self.getCursor()
        if tupla is None:
            self.__cursor.execute( sql )
        else:
            self.__cursor.execute( sql, tupla)

        return self.__cursor.fetchall()


    def __del__(self):
        self.__cursor.close()
        self.__connection.close()
        

if __name__ == "__main__":
    viewTraceback = False
    try:        
        db = DatabaseConnect()

        print('(1) Exibindo a parametrização para conexão ao banco de dados: ')
        print('*' * 50)
        print(db)

        print()
        print('(2) Conectando ao banco de dados: ')
        print('*' * 50)        
        conn = db.getConnection()
        print('\tDatabase connected sucessfuly.')

        print()
        print('(3) Submetendo uma instrução SQL (SELECT/INSERT/UPDATE/DELETE) ao BD: ')
        print('*' * 50) 
        sql = 'SELECT SUM(amount) FROM payment WHERE customer_id = %s'
        resultSet = db.submitsql(sql,(341,)) # submitsql() retorna uma lista de tuplas
        #print(type(resultSet))
        print(sql, 'id=341')
        print('Resultado: ',resultSet[0][0])

        print()
        print('(4) Exibindo a versão do banco:')
        print('*' * 50)
        db.version()
        
        #print(db.__dict__) # or DatabaseConnect.__dict__

    except psycopg2.OperationalError as oe:
        '''
        DatabaseError > OperationalError  (psycopg2)
        --------------------------------
        Exceção lançada para erros relacionados a operação do banco de dados, como por
        exemplo, desconexão inesperada, transação não processada, fonte de dados não
        encontrada, erro de alocação de memória, entre outros

        Documentação das exceções:
        http://initd.org/psycopg/docs/module.html
        '''
        print('CLASSE DO ERRO: ', oe.__class__.__name__ )
        print('=' * 35)
        print('Erro operacional no acesso ao banco de dados.')
        print(oe)
    except Exception as e:
        print()
        print('ERRO: ', e.__class__.__name__,'(Exceção)')
        print('=' * 35)
        print(e)

        if (viewTraceback):
            print('TRACEBACK: ')
            print(traceback.format_exc())

    else:
        print('Fechando a conexão...')
        conn.close()
    finally:
        print('Programa encerrado.')
        
